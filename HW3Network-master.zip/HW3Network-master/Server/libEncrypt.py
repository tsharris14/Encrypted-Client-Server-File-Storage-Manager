#Tyler Campise, TaCoya Harris CSCE 479 
#Description: 
# Created this module to handle all the encryption decryption for this project. This is based on https://pycryptodome.readthedocs.io/en/latest/src/cipher/classic.html
import json
import logging
from base64 import b64encode
from Cryptodome.Cipher import AES
from Cryptodome.Util.Padding import pad
from Cryptodome.Random import get_random_bytes

from base64 import b64decode
from Cryptodome.Util.Padding import unpad

#*******************************************************************
#standardizePassword
# Utility function to make sure that the user supplied password is always 16 bytes
# if the user provides a password that is too small it will overlay it on top of the base password to guarentee 16 bytes and this is important 
# when they go and unlock the file the p# this encrypts data by taking in a string key and a byte array of data and then uses the cryptodome libraries to encrypt the data uing the CBC encryption scheme 
#this code is based on the website mentioned above assword is consistant 
# if the user enters a password that is too big then this will truncate the password to 16 bytes 
#*******************************************************************
def standardizePassword(initialPassword):
    passwordBase = b'1234567890123456'
    bPasswordArray = bytearray(passwordBase)

    initPasswordArray = bytearray(initialPassword, encoding='utf-8')

    length = 16
    if len(initPasswordArray) < 16:
        length = len(initPasswordArray)

    for x in range(length):
        bPasswordArray[x] = initPasswordArray[x]

    logging.debug("StandardizePassword - New Password: {}".format(bPasswordArray.decode("utf-8")))
    return bPasswordArray 

#*******************************************************************
#EncryptMessage
# this encrypts data by taking in a string key and a byte array of data and then uses the cryptodome libraries to encrypt the data uing the CBC encryption scheme 
#this code is based on the website mentioned above 
#*******************************************************************
def EncryptMessage(key, data):
    cipher = AES.new(standardizePassword(key), AES.MODE_CBC)
    ct_bytes = cipher.encrypt(pad(data, AES.block_size))
    iv = b64encode(cipher.iv).decode('utf-8')
    ct = b64encode(ct_bytes).decode('utf-8')
    resultJson = json.dumps({'iv': iv, 'ciphertext':ct})

    #encode json result into base64 so that it comes back as one field/block of data
    encodedResult = b64encode(bytes(resultJson, 'utf-8')).decode('utf-8')
    return encodedResult

#*******************************************************************
#DecryptMessage
# this takes a string password and a byte array of encrypted data and returns a dict object 
# and returns two fields the status which determines if it was sucessful or not and the message which is the unencyrpted data
#this code is based on the website mentioned above 
#*******************************************************************
def DecryptMessage(key, encryptedMessage):
    message = ""
    status = "FAILED"

    try:
        #decode the block back into its json form
        decodedResult = b64decode(encryptedMessage)

        logging.debug("DecryptMessage - decoded result: {}".format(decodedResult))

        b64 = json.loads(decodedResult)
        iv2 = b64decode(b64['iv']);
        ct2 = b64decode(b64['ciphertext'])
        cipher2 = AES.new(standardizePassword(key), AES.MODE_CBC, iv2)
        message = unpad(cipher2.decrypt(ct2), AES.block_size)
        status = "SUCCESS"

        logging.debug("DecryptMessage - the message was:  {}".format(message))        
    except ValueError:
        logging.debug("ValueError: Incorrect descryption")
    except KeyError:
        logging.debug("KeyError: Incorrect descryption")

    return dict(status=status, message=message)


