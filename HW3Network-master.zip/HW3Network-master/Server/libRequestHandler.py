##Tyler Campise, TaCoya Harris CSCE 479 
#Description: this module handles the get and put requests from the client
import logging
import os
import hashlib

#*******************************************************************
#SaveFileToServer
#This method saves the file data to a directory named after the username using the original file name with the addition of adding the .encrypted at the end
#*******************************************************************
def SaveFileToServer(baseDirectory, username, filename, data, orgfilehash, encfilehash):
        path = os.path.join(baseDirectory, username)
        
        #if users directory doesn't exist create it
        if os.path.isdir(path) == False:
            os.mkdir(path)

        fullfilename = os.path.join(path, filename + ".encrypted")
        f = open(fullfilename, "wb+")
        f.write(bytes(orgfilehash, 'utf-8')) #store original file hash first in the file 
        f.write(bytes(encfilehash, 'utf-8')) #store encrypted file hash second 
        f.write(bytes(data, 'utf-8'))        #stores encrypted file data third 
        f.close()
        logging.debug("successfully saved {} for {}".format(filename, username))

#*******************************************************************
#GetFileFromServer
#This method pulls the file from the server and puts it in the response 
#*******************************************************************
def GetFileFromServer(baseDirectory, username, filename):
        path = os.path.join(baseDirectory, username)
        fullfilename = os.path.join(path, filename + ".encrypted")

        if os.path.isfile(fullfilename):
            with open(fullfilename, 'rb') as f:
                borgfilehash = f.read(32) #pulls original file hash first 
                bencfilehash = f.read(32) #pulls encrypted file hash second
                filedata = f.read()       #pulls the encrypted file data third
                print("successfully retrieved ({}) for {}".format(filename, username))

                storeHash = hashlib.md5(filedata).hexdigest()
                if storeHash != bencfilehash.decode('utf-8'):
                    content = {"action": "get", "status": "found/error", "description": "file corruption occurred", "username": username, "filename": filename, "filedata": filedata.decode('utf-8'),  "md5hash":borgfilehash.decode('utf-8)')}
                else:
                    content = {"action": "get", "status": "found", "description": "", "username": username, "filename": filename, "filedata": filedata.decode('utf-8'), "md5hash":borgfilehash.decode('utf-8)')}
        else:
            print("File ({}) NOT FOUND for {}".format(filename, username))
            content = {"action": "get", "status": "not found", "username": username, "filename": filename}

        return content

#*******************************************************************
#FilePutRequest
#this method handles the put request from the client
#*******************************************************************
def FilePutRequest(request, baseDirectory):
    username = request.get("username")
    filedata = request.get("filedata")
    filename = request.get("filename")
    orgfilehash = request.get("orgfilehash")
    encfilehash = request.get("encfilehash")
    clientpath = request.get("clientpath")

    SaveFileToServer(baseDirectory, username, filename, filedata, orgfilehash, encfilehash)
    
    #after pulling file from server double check the md5 hash from current file vs when it was initially stored 
    transferHash = hashlib.md5(bytearray(filedata, "utf-8")).hexdigest()
    if transferHash != encfilehash:
        print ("ERROR IN TRANSIT HASH DOES NOT MATCH")
        content = {"action": "put", "status": "ERROR", "description": "error in transit", "username": username, "filename": filename, "clientpath": clientpath}
    else:
        content = {"action": "put", "status": "success", "description":"success", "username": username, "filename": filename, "clientpath":clientpath}

    return content

#*******************************************************************
#FileGetRequest
#This method handles the get request from the client
#*******************************************************************
def FileGetRequest(request, baseDirectory):
    username = request.get("username")
    filename = request.get("filename")
    content = GetFileFromServer(baseDirectory, username, filename)

    return content


#*******************************************************************
#ServerRequestHandler
#This is the entry point of the module and is called by the libServer framework when a message is sent to the server
#*******************************************************************
def ServerRequestHandler(request, baseDirectory):
    action = request.get("action")
    
    ### PUT ###
    if action == "put":
        content = FilePutRequest(request, baseDirectory)

    ### GET ###
    elif action == "get":
        content = FileGetRequest(request, baseDirectory)
    else:
        content = {"status": f'Error: invalid action "{action}".'}

    return content
