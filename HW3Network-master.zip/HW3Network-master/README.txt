RUNNING INSTRUCTIONS FOR HW3

RUNNING THE SERVER SIDE:
First you have to go to the server directory in the command prompt and type 
>python3 hw3Server.py (host) (port) (base directory)


host = ip adress that you want to run this program. this will generally be 127.0.0.1
port = the port in which you want to run this program on. 
base directory = this is the directory in which you want to store the encrypted server files.

Example: you have created a shared directory at ~/HW3Share

>python3 hw3Server.py 127.0.0.1 3001 ~/HW3Share


note that the server will create sub directories under that share for each unique user id and the files will be stored in that directory.



RUNNING CLIENT SIDE:
You will need to go to the client directory in the command prompt and type
>python3 hw3Client.py (host) (port) (encrypt/none) (username) (action) (filepath) (password)


host = ip adress of the server that you want to connect to.
port = the port number on the server you want to connect to
encrypt/none = type "encrypt" here if you want to encrypt the channel that is sending the file. or "none" if you want the channel to be in clear text (note: file data will still be encrypted by password) the none feature was added for debugging
username = unique id for the user 
action = there are two actions "get" - will retrieve the file by that name. or "put" - which will take a full path to a file and copy that to the server.
filepath = for the get operation this is simply the file name you want. And for the put operation it is the full path to that file on the client side.
password = password that you want to use to encrypt the file.

Example: 

>python3 hw3Client.py 127.0.0.1 3001 encrypt johndoe put ./test.txt milo
