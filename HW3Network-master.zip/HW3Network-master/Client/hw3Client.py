##Tyler Campise, TaCoya Harris CSCE 479 
#Description: 
# This is the client program for saving and getting files to a secure server. Alot of this code is based on https://realpython.com/python-sockets/#echo-client-and-server
#!/usr/bin/env python3

import sys
import socket
import selectors
import traceback
import os
import logging#Tyler Campise, TaCoya Harris CSCE 479 
import hashlib
from base64 import b64encode

import libClient
from libEncrypt import EncryptMessage
from libEncrypt import DecryptMessage


sel = selectors.DefaultSelector()
#logging.basicConfig(level=logging.DEBUG)
logging.basicConfig(level=logging.WARNING)

#*******************************************************************
#create_putfilerequestdata
# This creates the request message to put a file on the given server 
#*******************************************************************
def create_putfilerequestdata(username, filepath, password):
    path, fileName = os.path.split(filepath)

    if not os.path.exists(filepath):
        print("Error {} does not exist".format(filepath))
        sys.exit(1)
        
    #opening the file in binary mode and reading all of the content of the file and loading it into the content variable 
    with open(filepath, 'rb') as f:
        content = f.read()

    data = EncryptMessage(password, content)


    #create MD5 hash values for original file content as well as encrypted content, this will be used later for integrity checks
    orgFileHash = hashlib.md5(content).hexdigest()
    encFileHash = hashlib.md5(bytearray(data, "utf-8")).hexdigest()
    
    #This all the info we are sending to thte server for this request
    return dict(action = "put", username = username, filename=fileName, filedata = data, orgfilehash=orgFileHash, encfilehash=encFileHash, clientpath=filepath)

#*******************************************************************
#create_getfilerequestdata#Tyler Campise, TaCoya Harris CSCE 479 k the server to get a file 
#*******************************************************************
def create_getfilerequestdata(username, filepath):
    head, fileName = os.path.split(filepath)
    return dict(action = "get", username =username, filename=fileName)
    
#*******************************************************************
#create_request
# this function helps create the requests to go to the server 
#*******************************************************************
def create_request(action, username, filepath, password, encrypted):
    requestdata = ""
    content_type = "text/json"

    if action == "put":
        content = create_putfilerequestdata(username, filepath, password)

    elif action == "get":
        content = create_getfilerequestdata(username, filepath)


    #if the user specified encrypt as part of command line then it will encrypt the channel between the server and the client 
    if encrypted.lower() == "encrypt":
        content_type = "encrypted/json"

    return dict(
            type = content_type,
            encoding = "utf-8",
            content = content,
            )

    

def start_connection(host, port, request,password):
    addr = (host, port)
    print("starting connection to", addr)
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.setblocking(False)
    sock.connect_ex(addr)
    events = selectors.EVENT_READ | selectors.EVENT_WRITE
    message = libClient.Message(sel, sock, addr, request, password)
    sel.register(sock, events, data=message)

#handle command line arguments 
if len(sys.argv) != 8:
   print("usage:", sys.argv[0], "<host> <port> <encrypt/none> <username> <action> <filepath> <password>")
   print("")
   sys.exit(1)

host = sys.argv[1]
port= int(sys.argv[2])
encrypted = sys.argv[3]
username = sys.argv[4]
action = sys.argv[5]
filepath = sys.argv[6]
password = sys.argv[7]

logging.debug ("COMMAND host:{}, port:{}, encryptedChannel:{}, username:{}, action:{}, filepath:{}, password:{}".format(host, port, encrypted, username, action, filepath, password))
request = create_request(action, username, filepath, password, encrypted)
start_connection(host, port, request, password)

try:
    while True:
        events = sel.select(timeout=1)
        for key, mask in events:
            message = key.data
            try:
                message.process_events(mask)
            except Exception:
                print(
                    "main: error: exception for",
                    f"{message.addr}:\n{traceback.format_exc()}",
                )
                message.close()
        # Check for a socket being monitored to continue.
        if not sel.get_map():
            break
except KeyboardInterrupt:
    print("caught keyboard interrupt, exiting")
finally:
    sel.close()

