##Tyler Campise, TaCoya Harris CSCE 479 
#Description: this module handles the get and put responses from the server
import logging
import os
from libEncrypt import DecryptMessage

#*******************************************************************
#ProcessFileGetResponse
#this method takes the encrypted file passed back from the server decrypts it and stores it in the same directory as the program
#this method also has error checking for a file not found on the server password doesnt match or errors with integrity from the server side 
#*******************************************************************
def ProcessFileGetResponse(response, password):
    status = response.get("status")
    if status == "found":
        logging.debug( "FOUND FILENAME: {}".format(response.get("filename")))

        result = DecryptMessage(password, response.get("filedata"))
        if result['status'] == "SUCCESS":
            with open(response.get("filename"), 'wb+') as f:
                f.write(result['message'])
                print (f"Successfully retrieved {response.get('filename')} for {response.get('username')}")
                #TO-DO SEND MESSAGE TO DELETE SERVER FILE
        else: 
            print (f"Incorrect password for {response.get('filename')} for {response.get('username')}")
    elif status == "found/error":
        print("Error: {}".format(response.get('description')))
    else:
        print (f"{response.get('filename')} was not found on the server for {response.get('username')}")

#*******************************************************************
#ProcessFilePutResponse
#this method handles the server response after the file has been put on the server. If successful it will delete the local copy of the file
#*******************************************************************
def ProcessFilePutResponse(response):
    status = response.get("status")

    if status == "success":
        os.remove(response.get('clientpath'))
        print ("Successfully transferred {} to server".format(response.get("filename")))
    else:
        print ("Error transferring {} to server ({})".format(response.get("filename"), response.get("description")))


#*******************************************************************
#ClientResponseHandler
#This is the entry point of the module and is called by the libClient framework when a message is recieved back from the server
#*******************************************************************
def ClientResponseHandler(response, password):
    action = response.get("action")

    if action == "get": 
        ProcessFileGetResponse(response, password)
    elif action == "put":
        ProcessFilePutResponse(response)            